﻿namespace AVTemp
{
    internal class PlugInfo
    {
        public const string GUID = "org.legal.gorillatag.modtemplate";
        public const string Name = "AvX";
        public const string Description = "Created by av with unity";
        public const string Version = "1.0.0";
    }
}
