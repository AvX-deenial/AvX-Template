﻿using System;
using System.Collections.Generic;
using System.Text;
using static AVTemp.Menu.WristMenu;

namespace AVTemp.Background.Methods
{
    public class Mods
    {
        #region Settings
        public static void ChangePageButtons()
        {
            fybvsfdhvuhsurusugthsuhuihsdfbvbygfysdgyrgygsgdfs++;
            if (fybvsfdhvuhsurusugthsuhuihsdfbvbygfysdgyrgygsgdfs > 3)
            {
                fybvsfdhvuhsurusugthsuhuihsdfbvbygfysdgyrgygsgdfs = 0;
            }
            if (fybvsfdhvuhsurusugthsuhuihsdfbvbygfysdgyrgygsgdfs == 0)
            {
                pageButtonType = ":Bottom:";
            }
            if (fybvsfdhvuhsurusugthsuhuihsdfbvbygfysdgyrgygsgdfs == 1)
            {
                pageButtonType = ":Sides:";
            }
            if (fybvsfdhvuhsurusugthsuhuihsdfbvbygfysdgyrgygsgdfs == 2)
            {
                pageButtonType = ":Triggers:";
            }
            if (fybvsfdhvuhsurusugthsuhuihsdfbvbygfysdgyrgygsgdfs == 3)
            {
                pageButtonType = ":Grips:";
            }
        }
        public static int fybvsfdhvuhsurusugthsuhuihsdfbvbygfysdgyrgygsgdfs;
        #endregion
        #region Rig Mods

        #endregion
        #region Movement Mods

        #endregion
        #region Tag Mods

        #endregion
        #region Visual Mods

        #endregion
        #region Safety Mods

        #endregion
        #region Fun Mods

        #endregion
        #region OP Mods

        #endregion
    }
}
